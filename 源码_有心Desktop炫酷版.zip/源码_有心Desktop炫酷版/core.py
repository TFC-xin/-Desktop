# -*- coding: utf-8 -*-
"""
有心Desktop - 核心引擎
供 GUI / 托盘 / exe 共用。负责:
  - 倒计时计算(下一次高考, 6月7日, 当天=0)
  - 壁纸文件夹扫描、文件名数字识别、匹配
  - 调用 Windows API 换壁纸(支持铺满/居中)
  - 每日状态记录、跨天自动换图的后台循环
  - 开机自启(注册表) 与 单实例IPC
"""
import ctypes
import json
import logging
import os
import re
import socket
import sys
import tempfile
import threading
import time
import winreg
from datetime import date, datetime, timedelta
from pathlib import Path


EXE_NAME = "有心Desktop.exe"

def _is_frozen() -> bool:
    return getattr(sys, "frozen", False)

def get_base_dir() -> Path:
    """程序所在目录(exe为exe目录), 配置/日志/壁纸都在这里"""
    if _is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

BASE_DIR = get_base_dir()
CONFIG_PATH = BASE_DIR / "config.json"
LOG_PATH = BASE_DIR / "gaokao_wallpaper.log"
STATE_PATH = BASE_DIR / "state.json"

IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}
EXAM_MONTH, EXAM_DAY = 6, 7
CHECK_INTERVAL = 1800  # 秒(半小时), 后台循环检测跨天的间隔


LOG_MAX_LINES = 100  # 日志文件仅保留最近 100 条


class _TrimmedFileHandler(logging.FileHandler):
    """写日志后把文件裁剪为最近 N 行, 避免日志无限增长。"""

    def __init__(self, filename, max_lines=LOG_MAX_LINES, encoding="utf-8"):
        super().__init__(filename, encoding=encoding)
        self._max_lines = max_lines
        self._trim()

    def _trim(self):
        try:
            self.flush()
            p = Path(self.baseFilename)
            if not p.exists():
                return
            lines = p.read_text("utf-8", errors="ignore").splitlines()
            if len(lines) > self._max_lines:
                p.write_text("\n".join(lines[-self._max_lines:]) + "\n", "utf-8")
            if self.stream is not None:
                self.stream.seek(0, os.SEEK_END)
        except Exception:
            pass

    def emit(self, record):
        super().emit(record)
        self._trim()


logger = logging.getLogger("gaokao")
logger.setLevel(logging.INFO)
if not logger.handlers:
    try:
        _fh = _TrimmedFileHandler(LOG_PATH, encoding="utf-8")
        _fh.setFormatter(logging.Formatter("%(asctime)s %(message)s"))
        logger.addHandler(_fh)
    except Exception:
        pass


DEFAULT_EXAMS = [{"name": "高考", "date": "06-07", "time": "09:00"}]


def _parse_exam_datetime(exam: dict, today: date = None) -> datetime:
    """把考试配置解析为具体 datetime; date 可为 'YYYY-MM-DD' 或 'MM-DD'(自动取下一次)"""
    today = today or date.today()
    raw = str(exam.get("date", "06-07")).strip()
    t = str(exam.get("time", "09:00")).strip()
    try:
        hh, mm = (int(x) for x in t.split(":"))
    except Exception:
        hh, mm = 9, 0
    if "-" in raw and raw.count("-") == 2:
        y, m, d = (int(x) for x in raw.split("-"))
        target = date(y, m, d)
    else:
        m, d = (int(x) for x in raw.split("-"))
        target = date(today.year, m, d)
        if today > target:
            target = date(today.year + 1, m, d)
    return datetime(target.year, target.month, target.day, hh, mm)


def next_exam_datetime(exam: dict, now: datetime = None) -> datetime:
    now = now or datetime.now()
    dt = _parse_exam_datetime(exam, now.date())
    if dt < now:
        # 已过, 推到下一年(仅对 MM-DD 模式生效; YYYY-MM-DD 模式不再后推)
        raw = str(exam.get("date", "06-07")).strip()
        if raw.count("-") == 1:
            dt = _parse_exam_datetime(exam, now.date() + timedelta(days=366))
    return dt


def get_exams(cfg: dict = None) -> list:
    cfg = cfg or load_config()
    exams = cfg.get("exams")
    if not exams:
        exams = list(DEFAULT_EXAMS)
    return exams


def get_active_exam(cfg: dict = None) -> dict:
    """返回当前活跃考试; active_exam 为 -1 或越界时自动取最近的未到期考试"""
    cfg = cfg or load_config()
    exams = get_exams(cfg)
    if not exams:
        return dict(DEFAULT_EXAMS[0])
    idx = cfg.get("active_exam", -1)
    if isinstance(idx, int) and 0 <= idx < len(exams):
        return exams[idx]
    # 自动: 取距离现在最近的未到期考试
    now = datetime.now()
    upcoming = [(next_exam_datetime(e, now), e) for e in exams]
    upcoming = [(dt, e) for dt, e in upcoming if dt >= now]
    if upcoming:
        upcoming.sort(key=lambda x: x[0])
        return upcoming[0][1]
    return exams[0]


def exam_target_date(exam: dict = None) -> date:
    """考试日期(只取日期部分, 兼容老代码调用 exam_date())"""
    exam = exam or get_active_exam()
    return _parse_exam_datetime(exam).date()


# 兼容旧 API
def exam_date(today: date = None) -> date:
    today = today or date.today()
    exam = get_active_exam()
    raw = str(exam.get("date", "06-07")).strip()
    if raw.count("-") == 2:
        return date(*(int(x) for x in raw.split("-")))
    m, d = (int(x) for x in raw.split("-"))
    target = date(today.year, m, d)
    if today > target:
        target = date(today.year + 1, m, d)
    return target


def countdown(today: date = None, exam: dict = None) -> int:
    """距离考试还有多少天(考试当天=0)"""
    today = today or date.today()
    exam = exam or get_active_exam()
    target = exam_target_date(exam)
    return (target - today).days


def countdown_timedelta(exam: dict = None, now: datetime = None):
    """倒计时到考试当天(当天0点), 不具体到时刻"""
    exam = exam or get_active_exam()
    now = now or datetime.now()
    target = exam_target_date(exam)
    td = datetime(target.year, target.month, target.day) - now
    return td if td.total_seconds() > 0 else timedelta(0)


def motto(day: int) -> str:
    if day > 300:
        return "夯实基础, 稳步前行"
    if day > 200:
        return "一轮复习, 查漏补缺"
    if day > 100:
        return "百日冲刺, 贵在坚持"
    if day > 30:
        return "最后冲刺, 全力以赴"
    if day > 3:
        return "调整状态, 从容应考"
    if day >= 1:
        return "准备好了, 就去创造奇迹"
    return "今日考试, 旗开得胜!"


def load_config() -> dict:
    cfg = {}
    if CONFIG_PATH.exists():
        try:
            cfg = json.loads(CONFIG_PATH.read_text("utf-8"))
        except Exception as e:
            logger.warning("config.json 解析失败: %s", e)
    cfg.setdefault("wallpaper_dir", str(BASE_DIR / "壁纸"))
    cfg.setdefault("fit_mode", "stretch")
    cfg.setdefault("exams", list(DEFAULT_EXAMS))
    cfg.setdefault("active_exam", -1)   # -1 = 自动选最近未到期考试
    cfg.setdefault("floating_widget", True)
    cfg.setdefault("widget_topmost", True)
    cfg.setdefault("float_geo", None)   # 浮窗位置大小: {x,y,w,h}
    cfg.setdefault("wm_geo", None)      # 水印浮窗位置: {x,y}
    cfg.setdefault("show_watermark", True)
    cfg.setdefault("theme_color", "#0078D4")
    cfg.setdefault("float_bg", "#0C1120")
    cfg.setdefault("wm_bg", "#121622")
    cfg.setdefault("float_bg_alpha", 255)
    cfg.setdefault("wm_bg_alpha", 255)
    return cfg

def save_config(cfg: dict):
    CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), "utf-8")

def wallpaper_dir() -> Path:
    p = Path(load_config()["wallpaper_dir"])
    if not p.is_absolute():
        p = BASE_DIR / p
    return p

def load_state() -> dict:
    try:
        return json.loads(STATE_PATH.read_text("utf-8"))
    except Exception:
        return {}

def save_state(d: dict):
    try:
        STATE_PATH.write_text(json.dumps(d, ensure_ascii=False, indent=2), "utf-8")
    except Exception:
        pass


_NUM_RE = re.compile(r"\d+")

def extract_day_number(stem: str):
    """取文件名中最后一个数字作为天数, 如 '高考倒计时100天' -> 100"""
    nums = _NUM_RE.findall(stem)
    if not nums:
        return None
    try:
        return int(nums[-1])
    except ValueError:
        return None

def list_images(folder: Path):
    """文件夹里全部图片, 按天数排序(无数字的排最后, 按名称)"""
    if not folder.is_dir():
        return []
    items = []
    for p in folder.iterdir():
        if p.suffix.lower() in IMAGE_EXTS and p.is_file():
            items.append((extract_day_number(p.stem), p))
    items.sort(key=lambda t: (t[0] is None, t[0] if t[0] is not None else 0, t[1].name.lower()))
    return items

def find_wallpaper(folder: Path, day: int):
    """文件名数字 == day 的图片; 多张用最近修改的"""
    if not folder.is_dir():
        return None
    cands = [p for n, p in list_images(folder) if n == day]
    if not cands:
        return None
    return max(cands, key=lambda p: p.stat().st_mtime)


SPI_SETDESKWALLPAPER = 0x0014
SPIF_UPDATEINIFILE = 0x01
SPIF_SENDCHANGE = 0x02
_apply_lock = threading.Lock()

# GUI 层可注入: 换壁纸前对图片做处理(如加水印), callable(Path)->Path
WALLPAPER_TRANSFORM = None

def set_wallpaper(path: Path, fit: str = "stretch"):
    """fit: stretch=全屏铺满 / center=原图居中"""
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop",
                             0, winreg.KEY_SET_VALUE)
        with key:
            winreg.SetValueEx(key, "TileWallpaper", 0, winreg.REG_SZ, "0")
            winreg.SetValueEx(key, "WallpaperStyle", 0, winreg.REG_SZ,
                              "0" if fit == "center" else "2")
    except Exception:
        pass
    target = Path(path).resolve()
    if WALLPAPER_TRANSFORM is not None:
        try:
            target = Path(WALLPAPER_TRANSFORM(target)).resolve()
        except Exception as e:
            logger.warning("壁纸水印处理失败, 用原图: %s", e)
    # 统一转成 BMP 写到临时 ASCII 路径: 规避中文路径 / 扩展名与内容不符(JPG 被命名成 .png) / PNG 兼容等问题
    target = _to_bmp(target)
    user32 = ctypes.windll.user32
    user32.SystemParametersInfoW.argtypes = [ctypes.c_uint, ctypes.c_uint,
                                             ctypes.c_wchar_p, ctypes.c_uint]
    user32.SystemParametersInfoW.restype = ctypes.c_bool
    ok = user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, str(target),
                                      SPIF_UPDATEINIFILE | SPIF_SENDCHANGE)
    if not ok:
        raise RuntimeError("SystemParametersInfoW 调用失败")


def _to_bmp(path: Path) -> Path:
    """用 Pillow 按内容解码并另存为临时 BMP; 失败则退回原路径。"""
    try:
        from PIL import Image
        with Image.open(path) as im:
            im = im.convert("RGB")
            tmp = Path(tempfile.gettempdir()) / "gaokao_wallpaper.bmp"
            im.save(tmp, "BMP")
        return tmp
    except Exception as e:
        logger.warning("转 BMP 失败, 直接用原图: %s", e)
        return path


def apply_today(force: bool = False) -> dict:
    """换上今天的倒计时壁纸, 返回 {ok, day, file, msg}"""
    with _apply_lock:
        day = countdown()
        folder = wallpaper_dir()
        if not force:
            st = load_state()
            if st.get("date") == date.today().isoformat() and st.get("day") == day:
                return {"ok": True, "day": day, "file": st.get("file"), "msg": "今日壁纸已是最新"}
        img = find_wallpaper(folder, day)
        if img is None:
            msg = "在 %s 里没有找到文件名带 %s 的图片" % (folder, day)
            logger.warning("第 %s 天: %s", day, msg)
            return {"ok": False, "day": day, "file": None, "msg": msg}
        try:
            set_wallpaper(img, load_config().get("fit_mode", "stretch"))
        except Exception as e:
            msg = "设置壁纸失败(%s): %s" % (img.name, e)
            logger.error(msg)
            return {"ok": False, "day": day, "file": img.name, "msg": msg}
        save_state({"date": date.today().isoformat(), "day": day, "file": img.name})
        logger.info("已换壁纸: 剩余%s天 -> %s", day, img.name)
        return {"ok": True, "day": day, "file": img.name, "msg": "已更换: " + img.name}

def seconds_until_next_day(now: datetime = None) -> float:
    """距离次日 0 点还有多少秒。"""
    now = now or datetime.now()
    tomorrow = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return (tomorrow - now).total_seconds()


def run_daily_loop(on_change=None):
    """常驻: 每次开机启动都重新计算并强制换一次, 之后跨天0点后自动换。
    on_change(状态dict) 为可选回调"""
    apply_today(force=True)  # 开机必换: 静默启动 -> 计算倒计时 -> 换对应壁纸
    if on_change:
        try:
            on_change(load_state())
        except Exception:
            pass
    last_date = date.today()
    logger.info("后台循环启动, 每 %d 秒检测一次跨天", CHECK_INTERVAL)
    while True:
        try:
            if date.today() != last_date:
                last_date = date.today()
                apply_today()
                if on_change:
                    try:
                        on_change(load_state())
                    except Exception:
                        pass
        except Exception as e:
            logger.error("每日循环异常: %s", e)
        time.sleep(min(CHECK_INTERVAL, max(1.0, seconds_until_next_day())))


RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_VALUE = "GaokaoWallpaper"

def _autostart_command() -> str:
    if _is_frozen():
        return '"%s" --minimized' % sys.executable
    pyw = Path(sys.executable).with_name("pythonw.exe")
    exe = str(pyw if pyw.exists() else sys.executable)
    return '"%s" "%s" --minimized' % (exe, Path(__file__).resolve())

def is_autostart_enabled() -> bool:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_READ) as k:
            winreg.QueryValueEx(k, RUN_VALUE)
        return True
    except OSError:
        return False

def set_autostart(enabled: bool):
    try:
        if enabled:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, RUN_VALUE, 0, winreg.REG_SZ, _autostart_command())
        else:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, RUN_VALUE)
    except OSError as e:
        logger.error("修改开机自启失败: %s", e)


def get_wallpaper_layer_hwnd():
    """返回桌面壁纸层(WorkerW)窗口句柄。把浮窗 SetParent 到它上面,
    浮窗就会显示在桌面壁纸上、所有应用窗口之下。失败返回 None。"""
    try:
        user32 = ctypes.windll.user32
        progman = user32.FindWindowW("Progman", None)
        if not progman:
            return None
        result = ctypes.c_ulong()
        # 0x052C: 让 Progman 生成一个承载壁纸的 WorkerW
        user32.SendMessageTimeoutW(progman, 0x052C, 0, 0, 0x0000, 1000,
                                   ctypes.byref(result))
        workerw = ctypes.c_void_p(0)
        WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

        def _cb(tophandle, _lp):
            # 找到承载桌面图标(SHELLDLL_DefView)的顶层窗口,
            # 它后面那个 WorkerW 就是壁纸层
            defview = user32.FindWindowExW(tophandle, None, "SHELLDLL_DefView", None)
            if defview:
                w = user32.FindWindowExW(None, tophandle, "WorkerW", None)
                if w:
                    workerw.value = w
            return True

        user32.EnumWindows(WNDENUMPROC(_cb), 0)
        return workerw.value or None
    except Exception as e:
        logger.warning("获取桌面壁纸层失败: %s", e)
        return None


IPC_PORT = 59873

def _ipc_connect_send(payload: bytes, timeout=0.5) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", IPC_PORT), timeout=timeout) as s:
            s.sendall(payload)
            return True
    except OSError:
        return False

def notify_running_instance() -> bool:
    """已有实例在跑则让它弹出主窗口, 返回 True(新实例应退出)"""
    return _ipc_connect_send(b"show")

def start_ipc_server(show_callback):
    """后台线程监听 show 消息, 收到后调用 show_callback()"""
    def serve():
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind(("127.0.0.1", IPC_PORT))
            srv.listen(4)
        except OSError:
            return
        while True:
            try:
                conn, _ = srv.accept()
                data = conn.recv(16)
                conn.close()
                if data == b"show":
                    show_callback()
            except OSError:
                continue
    threading.Thread(target=serve, daemon=True).start()

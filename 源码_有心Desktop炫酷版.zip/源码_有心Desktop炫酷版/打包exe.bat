@echo off
rem 一键打包: 生成 onedir 文件夹版 (有心Desktop 文件夹) 并签名
rem 需要: pip install pyinstaller
chcp 65001 >nul
cd /d "%~dp0"
python -m PyInstaller --noconfirm --clean --onedir --windowed ^
  --name "有心Desktop" ^
  --icon "icon.ico" ^
  --add-data "icon.png;." ^
  --add-data "hero_bg.png;." ^
  --add-data "launch.gif;." ^
  --exclude-module PySide6.QtWebEngineCore ^
  --exclude-module PySide6.QtWebEngineWidgets ^
  --exclude-module PySide6.QtQuick3D ^
  --exclude-module PySide6.Qt3DCore ^
  --exclude-module PySide6.QtCharts ^
  --exclude-module PySide6.QtDataVisualization ^
  --exclude-module scipy ^
  --exclude-module win32com ^
  --exclude-module pythoncom ^
  --exclude-module pywintypes ^
  --exclude-module pythonwin ^
  --exclude-module Tkinter ^
  --exclude-module unittest ^
  app.py
if errorlevel 1 (
  echo [错误] 打包失败, 请检查上方报错信息。
  pause & exit /b 1
)

rem 只刷新程序文件, 保留 有心Desktop 里的 config.json / state.json / 壁纸 / 日志
if exist "有心Desktop\_internal" rmdir /s /q "有心Desktop\_internal"
xcopy /e /i /y "dist\有心Desktop" "有心Desktop" >nul

echo [签名] 使用 CN=TFC* 证书签名...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$c = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Subject -like 'CN=TFC*' } | Select-Object -First 1; if (-not $c) { Write-Host '[警告] 未找到证书, 跳过签名' } else { Set-AuthenticodeSignature -FilePath '有心Desktop\有心Desktop.exe' -Certificate $c -HashAlgorithm SHA256 -TimestampServer 'http://timestamp.digicert.com' | Select-Object Status, StatusMessage | Format-List }"

echo.
echo [完成] 有心Desktop\有心Desktop.exe 已生成, 双击即可运行。
pause

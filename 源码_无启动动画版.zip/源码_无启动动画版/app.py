# -*- coding: utf-8 -*-
"""
有心Desktop - 主程序 (QFluentWidgets / Fluent Design 风格)
  主页: 壁纸设置 + 画廊
  设置: 开机自启 / 浮窗 / 水印 / 主题色 / 考试管理 / 功能自检
  浮窗与水印压到 Z 序底部(所有应用窗口之下、桌面之上), 可拖动并记忆位置
"""
import os
import json
import random
import sys
import ctypes
import threading
import time
import urllib.request
from datetime import date
from pathlib import Path

from PySide6.QtCore import (QPoint, QRect, QRectF, QSize, QTimer, Qt, Signal, Slot,
                            QEasingCurve, QPropertyAnimation, QEvent)
from PySide6.QtGui import (QAction, QBrush, QColor, QFont, QFontMetrics, QIcon, QImageReader,
                           QPainter, QPainterPath, QPen, QPixmap, QLinearGradient, QMovie)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QMessageBox, QMenu, QPushButton, QScrollArea, QSizeGrip,
                               QSizePolicy, QGraphicsOpacityEffect,
                               QSystemTrayIcon, QVBoxLayout, QWidget, QFileDialog)

from qfluentwidgets import (FluentWindow, FluentIcon, Theme, setTheme, setThemeColor,
                            PushButton, PrimaryPushButton, LineEdit, ComboBox, CheckBox,
                            ListWidget, BodyLabel, SubtitleLabel, StrongBodyLabel, CaptionLabel,
                            CardWidget, InfoBar, InfoBarPosition, ColorPickerButton, SpinBox,
                            SettingCard, PopUpAniStackedWidget, ToolButton)

import core

BASE_DIR = core.BASE_DIR


def res_path(name: str) -> Path:
    candidates = []
    if getattr(sys, "frozen", False):
        candidates.append(Path(getattr(sys, "_MEIPASS", BASE_DIR)) / name)
        candidates.append(Path(sys.executable).resolve().parent / name)
    candidates.append(BASE_DIR / name)
    for c in candidates:
        if c.exists():
            return c
    return candidates[0]


def rounded_pixmap(pm: QPixmap, radius: int) -> QPixmap:
    out = QPixmap(pm.size())
    out.fill(Qt.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    path = QPainterPath()
    path.addRoundedRect(0, 0, pm.width(), pm.height(), radius, radius)
    p.setClipPath(path)
    p.drawPixmap(0, 0, pm)
    p.end()
    return out


HITOKOTO_URL = "https://v1.hitokoto.cn"

HITOKOTO_CATS = ("d", "e", "f", "j", "k")
HITOKOTO_MIN = 0
HITOKOTO_MAX = 20
HITOKOTO_CAT_NAMES = {
    "a": "动画", "b": "漫画", "d": "文学", "e": "原创", "f": "来自网络",
    "g": "其他", "h": "影视", "j": "网易云", "k": "哲学",
}

OFFLINE_QUOTES = [
    "路行且慢，总有好光景。",
    "把日子过成自己喜欢的样子。",
    "答案有时在路上，不在首页。",
    "今天也要努力靠近想要的生活。",
    "慢慢来，比较快。",
    "愿你眼中有光，心中有方向。",
    "你所热爱的，会把你带到想去的地方。",
    "保持热爱，奔赴山海。",
    "距离高考的日子，每一天都算数。",
    "坚持本身就是一种天赋。",
]


FX_NAMES = ["none", "marquee", "breathing", "rainbow"]
FX_LABELS = ["无", "跑马灯", "呼吸灯", "彩虹流动"]


def fx_solid(base: QColor, fx: str, phase: int, idx: int = 0) -> QColor:
    """效果的纯色近似: 呼吸灯按相位调透明度, 彩虹按序位转色相, 其余返回基色。"""
    c = QColor(base)
    if fx == "breathing":
        c.setAlpha(int(80 + 175 * (0.5 + 0.5 * math.sin(phase * 0.1))))
    elif fx == "rainbow":
        c = QColor.fromHsv(int((phase * 4 + idx * 90) % 360), 200, 255)
    return c


def fx_marquee_brush(base: QColor, br: QRectF, phase: int) -> QBrush:
    """跑马灯: 一道高亮光带沿文字横向扫过。"""
    t = (phase % 70) / 70.0
    c = QColor(base)
    if c.saturation() < 40:
        light = QColor.fromHsv(int((phase * 5) % 360), 170, 255)
    else:
        light = c.lighter(190)
    g = QLinearGradient(br.left(), 0, br.right(), 0)
    g.setColorAt(0.0, c)
    g.setColorAt(max(0.0, t - 0.18), c)
    g.setColorAt(t, light)
    g.setColorAt(min(1.0, t + 0.18), c)
    g.setColorAt(1.0, c)
    return QBrush(g)


class FxMixin:
    """浮窗文字动态效果: 50ms 相位推进 + 重绘, fx=none 时定时器停摆。"""

    def _init_fx(self, cfg, key):
        self._fx = cfg.get(key, "none")
        self._fx_phase = 0
        self._fx_timer = QTimer(self)
        self._fx_timer.timeout.connect(self._fx_step)

    def set_fx(self, name):
        self._fx = name if name in FX_NAMES else "none"
        if self._fx == "none":
            self._fx_timer.stop()
        else:
            self._fx_timer.start(50)
        self._on_fx_changed()

    def _fx_step(self):
        self._fx_phase += 1
        self._on_fx_changed()

    def _on_fx_changed(self):
        self.update()

    def start_fx_if_needed(self):
        if self._fx != "none":
            self._fx_timer.start(50)


def rebuild_hitokoto_params():
    """按 config 刷新主页一言请求参数(分类/长度)。"""
    global HITOKOTO_CATS, HITOKOTO_MIN, HITOKOTO_MAX
    cfg = core.load_config()
    cats = cfg.get("home_cats")
    if isinstance(cats, list) and cats:
        HITOKOTO_CATS = tuple(str(c) for c in cats)
    else:
        HITOKOTO_CATS = ("d", "e", "f", "j", "k")
    HITOKOTO_MIN = int(cfg.get("home_min", 0) or 0)
    HITOKOTO_MAX = int(cfg.get("home_max", 20) or 20)


def fetch_hitokoto(timeout=3.0, cats=None, min_len=None, max_len=None):
    cats = cats if cats is not None else HITOKOTO_CATS
    min_len = HITOKOTO_MIN if min_len is None else int(min_len)
    max_len = HITOKOTO_MAX if max_len is None else int(max_len)
    if not cats:
        return None
    params = "&".join("c=" + str(c) for c in cats)
    url = "%s/?min_length=%d&max_length=%d&%s" % (HITOKOTO_URL, min_len, max_len, params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
        return (data.get("hitokoto") or "").strip() or None
    except Exception:
        return None


def _qwidget_fetch():
    """桌面一言打字机专用请求: 使用独立的一套(cats/min/max)。"""
    cfg = core.load_config()
    cats = cfg.get("tw_cats")
    if not isinstance(cats, list):
        cats = ("d", "e", "f", "j", "k")
    return fetch_hitokoto(
        cats=[str(c) for c in cats],
        min_len=cfg.get("tw_min", 0) or 0,
        max_len=cfg.get("tw_max", 40) or 40,
    )


class QuoteProvider:
    def __init__(self, fallback, fetch=None, interval=1.5):
        self._fallback = [s for s in fallback if s]
        self._fetch = fetch or fetch_hitokoto
        self._interval = interval
        self._queue = []
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._paused = threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        while True:
            if self._paused.is_set():
                self._paused.wait()
                continue
            q = self._fetch()
            if q:
                with self._lock:
                    if len(self._queue) < 40:
                        self._queue.append(q)
            self._wake.wait(self._interval)
            self._wake.clear()

    def pause(self):
        self._paused.set()

    def resume(self):
        self._paused.clear()

    def refresh(self):
        """唤醒后台线程立刻去取一条新内容(不阻塞界面)。"""
        self._wake.set()

    def drain(self):
        with self._lock:
            out, self._queue = self._queue, []
        return out

    def fallback(self):
        return random.choice(self._fallback) if self._fallback else ""


class TypewriterLabel(QLabel):
    finished = Signal()

    def __init__(self, char_delay=200, del_delay=60, hold=1800, cycle=True, jitter=0, parent=None):
        super().__init__(parent)
        self._texts = []
        self._cycle = cycle
        self._char_delay = char_delay
        self._del_delay = del_delay
        self._hold = hold
        self._jitter = jitter
        self._qi = 0
        self._ci = 0
        self._deleting = False
        self._cursor_on = True
        self.setText("")
        self.setAlignment(Qt.AlignCenter)
        self.setWordWrap(True)
        self._sweep_active = False
        self._sweep_phase = 0
        self._sweep_base = QColor("#FFFFFF")

        self._type_timer = QTimer(self)
        self._type_timer.timeout.connect(self._step)
        self._cursor_timer = QTimer(self)
        self._cursor_timer.timeout.connect(self._blink)
        self._cursor_timer.start(700)

    def set_quotes(self, texts):
        """整体替换内容并立刻从头打字(用于「立即更新」)。"""
        self._texts = [t for t in texts if t]
        self._qi = 0
        self._ci = 0
        self._deleting = False
        self._render()
        self._type_timer.stop()
        if self._texts:
            self._type_timer.start(self._char_delay)

    def append_quotes(self, texts):
        self._texts.extend(t for t in texts if t)
        if self._texts and not self._type_timer.isActive():
            self._type_timer.start(self._char_delay)

    def _shown(self):
        if not self._texts:
            return ""
        return self._texts[self._qi][:self._ci]

    def _blink(self):
        self._cursor_on = not self._cursor_on
        self._render()

    def _render(self):
        cursor = "|" if self._cursor_on else " "
        self.setText(self._shown() + cursor)

    def _next_delay(self, base):
        if self._jitter:
            return base + random.randint(0, self._jitter)
        return base

    def _step(self):
        if not self._texts:
            return
        q = self._texts[self._qi]
        if not self._deleting:
            if self._ci < len(q):
                self._ci += 1
                self._render()
                self._type_timer.start(self._next_delay(self._char_delay))
            else:
                if not self._cycle:
                    self._type_timer.stop()
                    self._render()
                    self.finished.emit()
                    return
                self._deleting = True
                self._type_timer.start(self._hold)
        else:
            if self._ci > 0:
                self._ci -= 1
                self._render()
                self._type_timer.start(self._next_delay(self._del_delay))
            else:
                self._deleting = False
                self._qi = (self._qi + 1) % len(self._texts)
                self._type_timer.start(self._next_delay(self._char_delay))

    def set_sweep(self, active, phase=0, base=None):
        """跑马灯模式: 用光带从左扫到右代替整体变色。"""
        self._sweep_active = active
        self._sweep_phase = phase
        if base is not None:
            self._sweep_base = QColor(base)
        self.update()

    def paintEvent(self, ev):
        if not self._sweep_active:
            return super().paintEvent(ev)
        text = self.text()
        if not text:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        p.setFont(self.font())
        w, h = self.width(), self.height()
        t = (self._sweep_phase % 70) / 70.0
        base = QColor(self._sweep_base)
        if base.saturation() < 40:
            light = QColor.fromHsv(int((self._sweep_phase * 5) % 360), 170, 255)
        else:
            light = base.lighter(190)
        g = QLinearGradient(0, 0, w, 0)
        g.setColorAt(0.0, base)
        g.setColorAt(max(0.0, t - 0.18), base)
        g.setColorAt(t, light)
        g.setColorAt(min(1.0, t + 0.18), base)
        g.setColorAt(1.0, base)
        p.setPen(QPen(QBrush(g), 1))
        p.drawText(QRectF(0, 0, w, h), self.alignment() | Qt.TextWordWrap, text)


def _hero_background() -> QPixmap:
    try:
        bg = res_path("hero_bg.png")
        if bg.exists():
            pm = QPixmap(str(bg))
            if not pm.isNull():
                return pm
    except Exception as e:
        core.logger.warning("加载主页背景失败: %s", e)
    return QPixmap()


class HeroWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("hero")
        # 告诉 FluentWindow: 本页自己画背景, 底层 stackedWidget 需透明, 否则移动窗口时会闪一下浅色背景
        self.setProperty("isStackedTransparent", True)
        self._bg = _hero_background()
        self._bg_ok = not self._bg.isNull()
        self._bg_scaled = None
        self._last_size = QSize(0, 0)
        # 该页 paintEvent 会铺满整个区域, 声明为不透明可避免子控件刷新时连带重绘整页背景
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)

        self._caption = QLabel("Your can't please everyone.")
        self._caption.setAlignment(Qt.AlignCenter)
        self._caption.setStyleSheet("color:white; font-size:44px; font-weight:800;")

        self._typed = TypewriterLabel(char_delay=200, del_delay=70, hold=5000, cycle=True, jitter=60)
        self._typed.setStyleSheet("color:rgba(255,255,255,215); font-size:18px;")
        self._typed.setMinimumWidth(460)
        # 固定高度, 防止打字/光标闪烁时 label 高度变化触发 layout 重排导致上下跳动
        self._typed.setFixedHeight(54)

        self._prov = QuoteProvider([])
        self._prov._fallback = OFFLINE_QUOTES[:]
        self._fallback_gap = 0
        self._typed.set_quotes([])

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 24, 24, 72)
        lay.setSpacing(8)
        lay.addStretch(1)
        lay.addWidget(self._caption, 0, Qt.AlignCenter)
        lay.addSpacing(20)
        lay.addWidget(self._typed, 0, Qt.AlignCenter)
        lay.addStretch(1)

        self._feed_timer = QTimer(self)
        self._feed_timer.timeout.connect(self._feed)
        self._feed_timer.start(2000)

    def _feed(self):
        drained = self._prov.drain()
        if drained:
            self._fallback_gap = 0
            self._typed.append_quotes(drained)
            return
        self._fallback_gap += 1
        if self._fallback_gap >= 4:
            self._fallback_gap = 0
            fb = self._prov.fallback()
            if fb:
                self._typed.append_quotes([fb])

    def pause_feed(self):
        """主页不可见(最小化/隐藏)时停止更新, 避免无谓请求。"""
        self._feed_timer.stop()
        self._prov.pause()

    def resume_feed(self):
        """重新显示时立即刷新一次内容。"""
        self._prov.resume()
        if not self._feed_timer.isActive():
            self._feed_timer.start(2000)
        self._feed()

    def resizeEvent(self, ev):
        old = ev.oldSize()
        new = self.size()
        # 拖动窗口时 DWM 会让尺寸有 1-2px 波动, 过滤掉避免 layout 重排导致内容上下跳动
        if old.isValid() and abs(new.width() - old.width()) <= 3 and abs(new.height() - old.height()) <= 3:
            return
        super().resizeEvent(ev)
        self._rebuild_bg()

    def _rebuild_bg(self):
        if not self._bg_ok:
            self._bg_scaled = None
            return
        w, h = self.width(), self.height()
        if w < 2 or h < 2:
            return
        sz = QSize(w, h)
        if sz == self._last_size and self._bg_scaled is not None:
            return
        self._last_size = sz
        self._bg_scaled = self._bg.scaled(w, h, Qt.KeepAspectRatioByExpanding,
                                          Qt.SmoothTransformation)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        if self._bg_ok and self._bg_scaled is not None and not self._bg_scaled.isNull():
            p.drawPixmap(0, 0, self._bg_scaled)
        else:
            g = QLinearGradient(0, 0, 0, self.height())
            g.setColorAt(0.0, QColor("#24355F"))
            g.setColorAt(1.0, QColor("#0B1020"))
            p.fillRect(self.rect(), g)
        p.fillRect(self.rect(), QColor(0, 0, 0, 72))


def send_to_bottom(widget) -> bool:
    try:
        hwnd = int(widget.winId())
        u = ctypes.windll.user32
        u.SetWindowPos.restype = ctypes.c_bool
        u.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                   ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        HWND_BOTTOM = 1
        SWP_NOMOVE = 0x0002
        SWP_NOSIZE = 0x0001
        SWP_NOACTIVATE = 0x0010
        return bool(u.SetWindowPos(ctypes.c_void_p(hwnd), ctypes.c_void_p(HWND_BOTTOM),
                                   0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE))
    except Exception as e:
        core.logger.warning("浮窗沉底失败: %s", e)
        return False


class FloatingWidget(FxMixin, QWidget):
    def __init__(self):
        super().__init__()
        # 不置顶; 压到 Z 序底部后始终在其他应用之下
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnBottomHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        self.setMinimumSize(280, 200)
        self._drag = False
        self._drag_pos = QPoint()
        self._vals = (0, 0, 0, 0)
        self._locked = None
        self._interacting = False
        self._f_en = self._f_num = self._f_unit = None

        cfg = core.load_config()
        self._bg = QColor(cfg.get("float_bg", "#0C1120"))
        self._bg.setAlpha(cfg.get("float_bg_alpha", 255))
        self._fg = QColor(cfg.get("float_fg", "#FF7A6C"))
        self._init_fx(cfg, "float_fx")
        geo = cfg.get("float_geo")
        r = self._clamp_on_screen(self._rect_from_cfg(geo)) if geo else None
        if r is None:
            screen = QApplication.primaryScreen().availableGeometry()
            r = QRect(screen.right() - 460, screen.top() + 60, 440, 320)
        self._locked = QRect(r)
        self.setGeometry(r)

        self.grip = QSizeGrip(self)
        self.grip.setFixedSize(18, 18)
        self.grip.setStyleSheet("QSizeGrip{background:transparent;}")
        self.grip.installEventFilter(self)
        self.grip.raise_()

        self._pinned = bool(cfg.get("widget_topmost", True))

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_geo)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)
        self._update_fonts()
        self._tick()
        self.start_fx_if_needed()

    def is_pinned(self) -> bool:
        return self._pinned

    def _toggle_pin(self):
        self._pinned = not self._pinned
        cfg = core.load_config()
        cfg["widget_topmost"] = self._pinned
        core.save_config(cfg)

    @staticmethod
    def _rect_from_cfg(geo):
        try:
            return QRect(int(geo["x"]), int(geo["y"]), int(geo["w"]), int(geo["h"]))
        except Exception:
            return None

    def _clamp_on_screen(self, r: QRect):
        if r is None:
            return None
        r = QRect(r)
        mn = self.minimumSize()
        r.setWidth(max(r.width(), mn.width()))
        r.setHeight(max(r.height(), mn.height()))
        screen = QApplication.screenAt(r.center()) or QApplication.primaryScreen()
        ag = screen.availableGeometry()
        r.setWidth(min(r.width(), ag.width()))
        r.setHeight(min(r.height(), ag.height()))
        x = min(max(r.x(), ag.left()), ag.right() - r.width() + 1)
        y = min(max(r.y(), ag.top()), ag.bottom() - r.height() + 1)
        r.moveTopLeft(QPoint(x, y))
        return r

    def enforce_geometry(self):
        # 用户拖动/缩放期间不干预; 其余时间把系统擅自改动的位置尺寸拉回锁定值
        if not self.isVisible() or self._locked is None:
            return
        if self._interacting or (QApplication.mouseButtons() & Qt.LeftButton):
            return
        exp = self._clamp_on_screen(self._locked)
        self._locked = QRect(exp)
        cur = self.geometry()
        if (abs(cur.x() - exp.x()) > 8 or abs(cur.y() - exp.y()) > 8
                or abs(cur.width() - exp.width()) > 4
                or abs(cur.height() - exp.height()) > 4):
            self.setGeometry(exp)

    def eventFilter(self, o, e):
        if o is self.grip:
            if e.type() == QEvent.MouseButtonPress:
                self._interacting = True
            elif e.type() in (QEvent.MouseButtonRelease, QEvent.Hide):
                self._interacting = False
        return super().eventFilter(o, e)

    def showEvent(self, ev):
        super().showEvent(ev)
        # 开机自启时显示系统可能还没就绪, 显示后再钉一次
        QTimer.singleShot(100, self.enforce_geometry)

    def set_bg(self, color, alpha=None):
        c = QColor(color)
        c.setAlpha(self._bg.alpha() if alpha is None else alpha)
        self._bg = c
        self.update()

    def set_fg(self, color):
        self._fg = QColor(color)
        self.update()

    def _save_geo(self):
        r = self._clamp_on_screen(self.geometry())
        if r != self.geometry():
            self.setGeometry(r)
            return
        self._locked = QRect(r)
        cfg = core.load_config()
        cfg["float_geo"] = {"x": r.x(), "y": r.y(), "w": r.width(), "h": r.height()}
        core.save_config(cfg)

    def _update_fonts(self):
        cw, ch = self.width() / 2, self.height() / 2
        f_en = QFont("Segoe UI")
        f_en.setPixelSize(max(11, int(ch * 0.11)))
        f_en.setBold(True)
        f_num = QFont("Georgia")
        f_num.setPixelSize(int(min(cw, ch) * 0.46))
        f_num.setBold(True)
        f_unit = QFont("Microsoft YaHei")
        f_unit.setPixelSize(max(12, int(ch * 0.13)))
        f_unit.setBold(True)
        self._f_en, self._f_num, self._f_unit = f_en, f_num, f_unit

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        self.grip.move(self.width() - 20, self.height() - 20)
        self._update_fonts()
        self._save_timer.start(400)

    def moveEvent(self, ev):
        super().moveEvent(ev)
        self._save_timer.start(400)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        w, h = self.width(), self.height()
        # 不透明整幅背景 (WorkerW 子窗口需要不透明才稳定渲染)
        p.fillRect(0, 0, w, h, self._bg)
        p.setPen(QPen(QColor(255, 255, 255, 30), 1))
        p.drawLine(w // 2, 0, w // 2, h)
        p.drawLine(0, h // 2, w, h // 2)

        cells = [("DAYS", "天"), ("HRS", "时"), ("MIN", "分"), ("SEC", "秒")]
        cw, ch = w / 2, h / 2
        for i, ((en, cn), val) in enumerate(zip(cells, self._vals)):
            cx = (i % 2) * cw
            cy = (i // 2) * ch
            p.setFont(self._f_en)
            p.setPen(QColor(126, 136, 160))
            p.drawText(QRectF(cx + 14, cy + 10, cw - 28, ch * 0.18), Qt.AlignLeft | Qt.AlignTop, en)

            nf = self._f_num
            text = "%02d" % val if i > 0 else str(val)
            path = QPainterPath()
            path.addText(0, 0, nf, text)
            br = path.boundingRect()
            tx = cx + cw / 2 - br.width() / 2 - br.left()
            ty = cy + ch * 0.52 - br.height() / 2 - br.top()
            solid = fx_solid(self._fg, self._fx, self._fx_phase, i)
            glow = QColor(solid)
            glow.setAlpha(min(70, solid.alpha()))
            edge = QColor(solid)
            edge.setAlpha(min(90, solid.alpha()))
            p.save()
            p.translate(tx, ty)
            p.setPen(Qt.NoPen)
            p.setBrush(glow)
            p.drawPath(path)
            p.strokePath(path, QPen(edge, max(3, ch * 0.045)))
            if self._fx == "marquee":
                p.fillPath(path, fx_marquee_brush(self._fg, br, self._fx_phase))
            else:
                p.fillPath(path, solid)
            p.restore()

            uf = self._f_unit
            p.setPen(QColor(233, 237, 246))
            p.drawText(QRectF(cx, cy + ch * 0.74, cw, ch * 0.2), Qt.AlignCenter, cn)

    def _tick(self):
        exam = core.get_active_exam()
        total = max(0, int(core.countdown_timedelta(exam).total_seconds()))
        self._vals = (total // 86400, (total % 86400) // 3600,
                      (total % 3600) // 60, total % 60)
        self.update()

    def mousePressEvent(self, ev):
        self._interacting = True
        if not self._pinned and ev.button() == Qt.LeftButton and ev.position().toPoint().y() > 24:
            self._drag = True
            self._drag_pos = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, ev):
        if self._drag and ev.buttons() & Qt.LeftButton:
            self.move(ev.globalPosition().toPoint() - self._drag_pos)

    def mouseReleaseEvent(self, _):
        self._drag = False
        self._interacting = False
        if not self._pinned:
            send_to_bottom(self)  # 拖动后重新沉底

    def contextMenuEvent(self, ev):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu{background:#1A2030;color:#E8ECF5;border:1px solid #2A3350;"
                           "border-radius:8px;padding:4px;} QMenu::item{padding:6px 22px;border-radius:5px;}"
                           "QMenu::item:selected{background:#2C3654;}")
        a_pin = menu.addAction("解锁移动" if self._pinned else "固定位置")
        a_reset = menu.addAction("复位位置")
        menu.addSeparator()
        a_close = menu.addAction("关闭浮窗")
        act = menu.exec(ev.globalPos())
        if act == a_pin:
            self._toggle_pin()
        elif act == a_reset:
            screen = QApplication.primaryScreen().availableGeometry()
            r = QRect(screen.right() - 460, screen.top() + 60, 440, 320)
            self._locked = QRect(r)
            self.setGeometry(r)
            send_to_bottom(self)
        elif act == a_close:
            self.hide()


WATERMARK_TEXT = "power by TFC"

class WatermarkWidget(FxMixin, QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnBottomHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self._drag = False
        self._drag_pos = QPoint()

        f = QFont("Segoe UI")
        f.setPixelSize(13)
        f.setBold(True)
        self._font = f
        fm = QFontMetrics(f)
        self.setFixedSize(fm.horizontalAdvance(WATERMARK_TEXT) + 24, fm.height() + 10)

        cfg = core.load_config()
        self._bg = QColor(cfg.get("wm_bg", "#121622"))
        self._bg.setAlpha(cfg.get("wm_bg_alpha", 255))
        self._fg = QColor(cfg.get("wm_fg", "#FFFFFF"))
        self._init_fx(cfg, "wm_fx")
        self._pinned = bool(cfg.get("wm_pinned", True))
        geo = cfg.get("wm_geo")
        if geo and self._on_screen(geo["x"], geo["y"]):
            self.move(geo["x"], geo["y"])
        else:
            screen = QApplication.primaryScreen().availableGeometry()
            self.move(screen.right() - self.width() - 24, screen.top() + 12)

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_pos)
        self.start_fx_if_needed()

    def _on_screen(self, x, y) -> bool:
        for s in QApplication.screens():
            ag = s.availableGeometry()
            if ag.left() - 50 < x < ag.right() and ag.top() - 50 < y < ag.bottom():
                return True
        return False

    def set_bg(self, color, alpha=None):
        c = QColor(color)
        c.setAlpha(self._bg.alpha() if alpha is None else alpha)
        self._bg = c
        self.update()

    def _save_pos(self):
        cfg = core.load_config()
        cfg["wm_geo"] = {"x": self.x(), "y": self.y()}
        core.save_config(cfg)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        w, h = self.width(), self.height()
        path = QPainterPath()
        path.addRoundedRect(0, 0, w, h, h / 2, h / 2)
        p.fillPath(path, self._bg)
        p.setFont(self._font)
        fm = QFontMetrics(self._font)
        total = fm.horizontalAdvance(WATERMARK_TEXT)
        x0 = (w - total) / 2
        y0 = (h + fm.ascent() - fm.descent()) / 2
        if self._fx == "rainbow":
            x = x0
            for idx, ch in enumerate(WATERMARK_TEXT):
                p.setPen(QColor.fromHsv(int((self._fx_phase * 5 + idx * 28) % 360), 200, 255))
                p.drawText(int(x), int(y0), ch)
                x += fm.horizontalAdvance(ch)
        elif self._fx == "marquee":
            tp = QPainterPath()
            tp.addText(x0, y0, self._font, WATERMARK_TEXT)
            p.fillPath(tp, fx_marquee_brush(self._fg, tp.boundingRect(), self._fx_phase))
        else:
            c = fx_solid(self._fg, self._fx, self._fx_phase)
            if self._fx == "none":
                c.setAlpha(240)
            p.setPen(c)
            p.drawText(QRectF(0, 0, w, h), Qt.AlignCenter, WATERMARK_TEXT)

    def _toggle_pin(self):
        self._pinned = not self._pinned
        cfg = core.load_config()
        cfg["wm_pinned"] = self._pinned
        core.save_config(cfg)

    def mousePressEvent(self, ev):
        if self._pinned:
            return
        if ev.button() == Qt.LeftButton:
            self._drag = True
            self._drag_pos = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, ev):
        if self._drag and ev.buttons() & Qt.LeftButton:
            self.move(ev.globalPosition().toPoint() - self._drag_pos)
            self._save_timer.start(400)

    def mouseReleaseEvent(self, _):
        self._drag = False
        send_to_bottom(self)  # 拖动后重新沉底

    def contextMenuEvent(self, ev):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu{background:#1A2030;color:#E8ECF5;border:1px solid #2A3350;"
                           "border-radius:8px;padding:4px;} QMenu::item{padding:6px 22px;border-radius:5px;}"
                           "QMenu::item:selected{background:#2C3654;}")
        a_pin = menu.addAction("解锁移动" if self._pinned else "固定位置")
        a_reset = menu.addAction("复位位置")
        menu.addSeparator()
        a_close = menu.addAction("关闭水印")
        act = menu.exec(ev.globalPos())
        if act == a_pin:
            self._toggle_pin()
        elif act == a_reset:
            screen = QApplication.primaryScreen().availableGeometry()
            self.move(screen.right() - self.width() - 24, screen.top() + 12)
            send_to_bottom(self)
        elif act == a_close:
            self.hide()


class QuoteWidget(FxMixin, QWidget):
    """桌面一言打字机: 独立背景/字体, 右键固定/解锁, 使用独立请求参数。"""

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Tool | Qt.WindowStaysOnBottomHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        self._drag = False
        self._drag_pos = QPoint()

        cfg = core.load_config()
        self._bg = QColor(cfg.get("quote_widget_bg", "#0C1120"))
        self._bg.setAlpha(cfg.get("quote_widget_bg_alpha", 255))
        self._pinned = bool(cfg.get("quote_widget_pinned", False))
        self._fs = int(cfg.get("quote_widget_fs", 16) or 16)
        self._fg = cfg.get("quote_widget_fg", "#FFFFFF")
        self._init_fx(cfg, "quote_fx")

        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_geo)

        # 停留 3 分钟后自动删除, 再打下一句: 「打字 → 停留3分钟 → 删除 → 再打字」
        self._typed = TypewriterLabel(char_delay=200, del_delay=70, hold=180000,
                                      cycle=True, jitter=60, parent=self)
        self._typed.setAlignment(Qt.AlignCenter)
        self._typed.setWordWrap(True)
        self.apply_font(self._fs)

        self.setMinimumSize(200, 70)
        geo = cfg.get("quote_widget_geo")
        if geo and self._geo_on_screen(geo):
            self.setGeometry(geo["x"], geo["y"], geo["w"], geo["h"])
        else:
            self.resize(420, max(90, self._fs * 3 + 40))
            screen = QApplication.primaryScreen().availableGeometry()
            self.move(screen.left() + 30, screen.bottom() - self.height() - 40)

        self.grip = QSizeGrip(self)
        self.grip.setFixedSize(18, 18)
        self.grip.setStyleSheet("QSizeGrip{background:transparent;}")
        self.grip.raise_()

        # 请求间隔(210秒)刻意长于一次完整循环(~185秒), 保证新内容在循环边界到达,
        # 不会插进删除动画中间; 内容只追加不重置, 因此「打字→停留→删除」永不被打断。
        self._provider = QuoteProvider([], fetch=_qwidget_fetch, interval=210)
        self._provider._fallback = OFFLINE_QUOTES[:]
        self._feed_timer = QTimer(self)
        self._feed_timer.timeout.connect(self._feed)
        self._feed_timer.start(2000)
        self._refresh_left = 0
        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self._poll_refresh)
        # 启动即有文字, 网络一言到位前先用离线文案占位, 避免空白
        self._typed.append_quotes(OFFLINE_QUOTES[:2])
        # 自定义右键菜单策略, 保证任何输入环境下都能弹出菜单
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_menu)
        self.start_fx_if_needed()

    def _geo_on_screen(self, g) -> bool:
        try:
            if g.get("w", 0) < 200 or g.get("h", 0) < 70:
                return False
            for s in QApplication.screens():
                ag = s.availableGeometry()
                if ag.left() - 100 < g["x"] < ag.right() and ag.top() - 100 < g["y"] < ag.bottom():
                    return True
        except Exception:
            pass
        return False

    def is_pinned(self) -> bool:
        return self._pinned

    def _toggle_pin(self):
        self._pinned = not self._pinned
        cfg = core.load_config()
        cfg["quote_widget_pinned"] = self._pinned
        core.save_config(cfg)

    def apply_font(self, fs, fg=None):
        self._fs = int(fs)
        if fg is not None:
            self._fg = fg
        f = QFont()
        f.setPixelSize(self._fs)
        f.setBold(True)
        self._typed.setFont(f)
        self._apply_fx_style()

    def _fx_color(self):
        base = QColor(self._fg)
        if self._fx == "breathing":
            # 纯亮度呼吸: 60~255 之间明暗循环
            return base, int(60 + 195 * (0.5 + 0.5 * math.sin(self._fx_phase * 0.12)))
        if self._fx == "rainbow":
            # 快速全色相闪烁
            return QColor.fromHsv(int((self._fx_phase * 16) % 360), 230, 255), 235
        return base, 235

    def _apply_fx_style(self):
        if self._fx == "marquee":
            self._typed.setStyleSheet("")
            self._typed.set_sweep(True, self._fx_phase, self._fg)
            return
        self._typed.set_sweep(False)
        c, a = self._fx_color()
        self._typed.setStyleSheet("color:rgba(%d,%d,%d,%d);" % (c.red(), c.green(), c.blue(), a))

    def _on_fx_changed(self):
        self._apply_fx_style()

    def set_fg(self, color):
        self._fg = color
        self.apply_font(self._fs)

    def set_bg(self, color, alpha=None):
        c = QColor(color)
        c.setAlpha(self._bg.alpha() if alpha is None else alpha)
        self._bg = c
        self.update()

    def _feed(self):
        """把新一言追加到播放列表(不重置当前循环), 打字机自行「打字→停留3分钟→删除→打下一条」。"""
        drained = self._provider.drain()
        if drained:
            self._typed.append_quotes(drained)

    def refresh_now(self):
        """立即取一条新一言并替换当前显示(网络在后台线程, 不卡界面)。"""
        self._provider.drain()      # 丢掉积压, 保证拿到的是新的
        self._provider.refresh()
        self._refresh_left = 8      # 最多等 2 秒
        self._refresh_timer.start(250)

    def _poll_refresh(self):
        drained = self._provider.drain()
        if drained:
            self._refresh_timer.stop()
            self._typed.set_quotes(drained[:1])
            return
        self._refresh_left -= 1
        if self._refresh_left <= 0:
            self._refresh_timer.stop()
            fb = self._provider.fallback()
            if fb:
                self._typed.set_quotes([fb])

    def resizeEvent(self, ev):
        self._typed.setGeometry(14, 12, self.width() - 28, self.height() - 24)
        grip = getattr(self, "grip", None)
        if grip is not None:
            grip.move(self.width() - grip.width() - 2, self.height() - grip.height() - 2)
            grip.raise_()
        self._save_timer.start(400)
        super().resizeEvent(ev)

    def _save_geo(self):
        r = self.geometry()
        cfg = core.load_config()
        cfg["quote_widget_geo"] = {"x": r.x(), "y": r.y(), "w": r.width(), "h": r.height()}
        core.save_config(cfg)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, self._bg)
        path = QPainterPath()
        path.addRoundedRect(0.5, 0.5, w - 1, h - 1, 14, 14)
        p.fillPath(path, self._bg)

    def mousePressEvent(self, ev):
        if not self._pinned and ev.button() == Qt.LeftButton:
            self._drag = True
            self._drag_pos = ev.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, ev):
        if self._drag and ev.buttons() & Qt.LeftButton:
            self.move(ev.globalPosition().toPoint() - self._drag_pos)
            self._save_timer.start(400)

    def mouseReleaseEvent(self, _):
        self._drag = False
        send_to_bottom(self)

    def _show_menu(self, pos):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu{background:#1A2030;color:#E8ECF5;border:1px solid #2A3350;"
                           "border-radius:8px;padding:4px;} QMenu::item{padding:6px 22px;border-radius:5px;}"
                           "QMenu::item:selected{background:#2C3654;}")
        a_pin = menu.addAction("解锁移动" if self._pinned else "固定位置")
        a_reset = menu.addAction("复位位置")
        menu.addSeparator()
        a_close = menu.addAction("关闭一言打字机")
        act = menu.exec(self.mapToGlobal(pos))
        if act == a_pin:
            self._toggle_pin()
        elif act == a_reset:
            screen = QApplication.primaryScreen().availableGeometry()
            self.resize(420, max(90, self._fs * 3 + 40))
            self.move(screen.left() + 30, screen.bottom() - self.height() - 40)
            send_to_bottom(self)
        elif act == a_close:
            self.hide()


class LoadingScreen(QWidget):
    finished = Signal()

    def __init__(self):
        super().__init__()
        self._movie = None
        self._gif_max = 0
        self._done = False
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(720, 220)

        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.center().x() - self.width() // 2,
                  screen.center().y() - self.height() // 2)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self._movie_label = QLabel()
        self._movie_label.setAlignment(Qt.AlignCenter)
        self._movie_label.hide()
        lay.addWidget(self._movie_label)

        # 没有动画文件时快速放行, 不阻塞启动
        if not self._start_launch_gif():
            QTimer.singleShot(300, self._finish)

    def _start_launch_gif(self) -> bool:
        gif = res_path("launch.gif")
        if not gif.exists():
            return False
        size = QImageReader(str(gif)).size()
        if not size.isValid() or size.isEmpty():
            return False
        movie = QMovie(str(gif))
        if not movie.isValid():
            return False

        screen = QApplication.primaryScreen()
        geo = screen.geometry()
        w, h = geo.width(), geo.height()

        # 全屏铺满: 按物理像素放大; 不整屏缓存(101 帧 × 1920×1080 会占约 800MB)
        movie.setScaledSize(QSize(int(w * screen.devicePixelRatio()),
                                  int(h * screen.devicePixelRatio())))
        movie.frameChanged.connect(self._on_gif_frame)
        movie.finished.connect(self._finish)

        self._movie = movie
        self._movie_label.setScaledContents(True)
        self._movie_label.setFixedSize(w, h)
        self._movie_label.setMovie(movie)
        self.setFixedSize(w, h)
        self.move(geo.x(), geo.y())
        self._movie_label.show()
        movie.start()
        # 循环播放的 GIF 不会触发 finished, 用超时兜底, 避免卡在加载页
        QTimer.singleShot(15000, self._finish)
        return True

    def _on_gif_frame(self, idx):
        """循环播放的 GIF 不触发 finished: 播到末帧后回到首帧时才主动收尾。"""
        if idx > self._gif_max:
            self._gif_max = idx
        elif idx == 0 and self._gif_max >= self._movie.frameCount() - 1:
            self._finish()

    def _finish(self):
        if self._done:
            return
        self._done = True
        if self._movie is not None:
            self._movie.stop()
        self.finished.emit()


class DayCard(CardWidget):
    def __init__(self, day, path: Path, fit_mode, parent=None):
        super().__init__(parent)
        self.setFixedSize(150, 176)
        self.setCursor(Qt.PointingHandCursor)
        self._path, self._fit = path, fit_mode
        self._thumb_loaded = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(6)
        self._thumb = QLabel()
        self._thumb.setFixedSize(132, 92)
        self._thumb.setAlignment(Qt.AlignCenter)
        lay.addWidget(self._thumb, 0, Qt.AlignHCenter)
        badge = QLabel("剩 %s 天" % day if day is not None else "未编号")
        badge.setAlignment(Qt.AlignCenter)
        badge.setStyleSheet("background:#FF4B4B; color:white; font-size:11px; font-weight:700;"
                            " border-radius:6px; padding:2px 8px;")
        lay.addWidget(badge, 0, Qt.AlignHCenter)
        name = QLabel(path.name)
        name.setAlignment(Qt.AlignCenter)
        name.setStyleSheet("color:#8A8A8A; font-size:11px;")
        name.setFixedWidth(132)
        name.setWordWrap(True)
        lay.addWidget(name, 0, Qt.AlignHCenter)
        self.setToolTip("%s\n点击立即设为壁纸" % path.name)

    def thumb_loaded(self) -> bool:
        return self._thumb_loaded

    def load_thumb(self):
        """按需解码缩略图: 300 张一次性同步解码要十几秒, 只解视口内的。"""
        if self._thumb_loaded:
            return
        self._thumb_loaded = True
        dpr = self.devicePixelRatioF()
        reader = QImageReader(str(self._path))
        reader.setScaledSize(QSize(int(132 * dpr), int(92 * dpr)))
        img = reader.read()
        if img.isNull():
            return
        pm = QPixmap.fromImage(img)
        pm.setDevicePixelRatio(dpr)
        self._thumb.setPixmap(rounded_pixmap(pm, 6))

    def mouseReleaseEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            try:
                core.set_wallpaper(self._path, self._fit)
                core.save_state({"date": date.today().isoformat(),
                                 "day": core.countdown(), "file": self._path.name})
                self.window().flash_status("已设为壁纸: " + self._path.name, ok=True)
            except Exception as e:
                self.window().flash_status("设置失败: %s" % e, ok=False)


class _NavSettingCard(SettingCard):
    """可点击的设置项卡片: 用于设置主页的功能列表, 点击进入子页面。"""

    clicked = Signal()

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(e)


class MainWindow(FluentWindow):
    stateChanged = Signal(dict)
    showRequested = Signal()

    def __init__(self, start_minimized=False):
        super().__init__()
        rebuild_hitokoto_params()
        self.setWindowTitle("有心Desktop")
        self.setFixedSize(1000, 680)
        # 去掉左上角返回箭头
        try:
            self.navigationInterface.setReturnButtonVisible(False)
        except Exception:
            pass
        self.showRequested.connect(self.show_and_raise)

        self._build_home()
        self._build_wallpaper_page()
        self._build_settings_page()
        self._build_tray()

        self.float_widget = FloatingWidget()
        self.wm_widget = WatermarkWidget()
        self.quote_widget = QuoteWidget()
        cfg = core.load_config()
        if cfg.get("floating_widget", True):
            self.float_widget.show()
        if cfg.get("show_watermark", True):
            self.wm_widget.show()
        if cfg.get("show_quote_widget", True):
            self.quote_widget.show()
        # 沉底到桌面(需等窗口创建后)
        QTimer.singleShot(200, self._send_widgets_to_bottom)

        # 周期性重新沉底, 防止被其他窗口盖住或系统重置 Z 序
        self._bottom_timer = QTimer(self)
        self._bottom_timer.timeout.connect(self._keep_bottom)
        self._bottom_timer.start(3000)

        self.stateChanged.connect(self.refresh_from_state)
        self.refresh_all()

        if start_minimized:
            self.hide()
            self.home.pause_feed()
        else:
            self.show()

    def _send_widgets_to_bottom(self):
        cfg = core.load_config()
        if cfg.get("floating_widget", True):
            send_to_bottom(self.float_widget)
        if cfg.get("show_watermark", True):
            send_to_bottom(self.wm_widget)
        if cfg.get("show_quote_widget", True):
            send_to_bottom(self.quote_widget)

    def _keep_bottom(self):
        cfg = core.load_config()
        if cfg.get("floating_widget", True) and self.float_widget.isVisible():
            send_to_bottom(self.float_widget)
            self.float_widget.enforce_geometry()
        if cfg.get("show_watermark", True) and self.wm_widget.isVisible():
            send_to_bottom(self.wm_widget)
        if cfg.get("show_quote_widget", True) and self.quote_widget.isVisible():
            send_to_bottom(self.quote_widget)

    def _build_home(self):
        self.home = HeroWidget()
        self.home.setObjectName("home")
        self.addSubInterface(self.home, FluentIcon.HOME, "主页")

    def _build_wallpaper_page(self):
        self.wallpaper_page = QWidget()
        self.wallpaper_page.setObjectName("wallpaper_page")
        self.addSubInterface(self.wallpaper_page, FluentIcon.PHOTO, "壁纸")

        outer = QVBoxLayout(self.wallpaper_page)
        outer.setContentsMargins(28, 20, 28, 20)
        outer.setSpacing(16)

        mid = QHBoxLayout()
        mid.setSpacing(16)
        mid.addWidget(self._build_wallpaper_card(), 5)
        mid.addWidget(self._build_gallery(), 6)
        outer.addLayout(mid, 1)

    def _build_wallpaper_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(14)
        v.addWidget(StrongBodyLabel("壁纸设置"))

        v.addWidget(CaptionLabel("壁纸文件夹"))
        row = QHBoxLayout()
        row.setSpacing(10)
        self.folder_edit = LineEdit()
        browse = PushButton("浏览")
        browse.clicked.connect(self.choose_folder)
        row.addWidget(self.folder_edit, 1)
        row.addWidget(browse)
        v.addLayout(row)
        tip = CaptionLabel("图片文件名带数字可自动识别")
        tip.setStyleSheet("color:#7A8296;")
        v.addWidget(tip)

        row2 = QHBoxLayout()
        row2.setSpacing(10)
        lab2 = CaptionLabel("显示方式")
        lab2.setFixedWidth(72)
        row2.addWidget(lab2)
        self.fit_combo = ComboBox()
        self.fit_combo.addItems(["全屏铺满(拉伸)", "原图居中(不拉伸)"])
        row2.addWidget(self.fit_combo)
        row2.addStretch()
        v.addLayout(row2)

        v.addSpacing(6)
        op = QHBoxLayout()
        op.setSpacing(10)
        apply_btn = PrimaryPushButton("立即更换")
        apply_btn.clicked.connect(self.apply_settings)
        open_btn = PushButton("打开壁纸文件夹")
        open_btn.clicked.connect(lambda: os.startfile(str(core.wallpaper_dir())))
        op.addWidget(apply_btn)
        op.addWidget(open_btn)
        op.addStretch()
        v.addLayout(op)
        v.addStretch()
        return card

    def _build_gallery(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(20, 20, 16, 16)
        v.setSpacing(12)
        head = QHBoxLayout()
        head.addWidget(StrongBodyLabel("壁纸画廊"))
        head.addStretch()
        self.gallery_count = CaptionLabel("")
        head.addWidget(self.gallery_count)
        refresh = PushButton("刷新")
        refresh.clicked.connect(self.refresh_gallery)
        head.addWidget(refresh)
        v.addLayout(head)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.gallery_holder = QWidget()
        self.gallery_grid = QGridLayout(self.gallery_holder)
        self.gallery_grid.setContentsMargins(0, 0, 6, 0)
        self.gallery_grid.setSpacing(12)
        self.scroll.setWidget(self.gallery_holder)
        v.addWidget(self.scroll, 1)

        # 缩略图懒加载: 只解视口内的, 滚动时用定时器防抖
        self._gal_cards = []
        self._gal_timer = QTimer(self)
        self._gal_timer.setSingleShot(True)
        self._gal_timer.setInterval(60)
        self._gal_timer.timeout.connect(self._load_visible_thumbs)
        self.scroll.verticalScrollBar().valueChanged.connect(
            lambda _=0: self._gal_timer.start())
        return card

    def _load_visible_thumbs(self):
        """分批解码视口附近(上下各 240px 边距)的缩略图, 每批 8 张避免卡顿。"""
        if not self._gal_cards:
            return
        vp = self.scroll.viewport()
        area = QRect(vp.rect()).adjusted(0, -240, 0, 240)
        budget = 8
        for c in self._gal_cards:
            if c.thumb_loaded():
                continue
            try:
                pos = c.mapTo(vp, QPoint(0, 0))
            except RuntimeError:
                continue
            if not (area.contains(pos) or area.contains(pos + QPoint(c.width(), c.height()))):
                continue
            c.load_thumb()
            budget -= 1
            if budget <= 0:
                self._gal_timer.start()
                return

    def _build_settings_page(self):
        self.settings_page = QWidget()
        self.settings_page.setObjectName("settings")
        self.addSubInterface(self.settings_page, FluentIcon.SETTING, "设置")

        self._settings_stack = PopUpAniStackedWidget(self.settings_page)

        cards = [
            ("general", "通用", "开机自启、单实例运行",
             FluentIcon.SETTING, self._build_general_card()),
            ("widget_bg", "桌面组件", "浮窗、水印、桌面一言的背景与字体",
             FluentIcon.BRUSH, self._build_widget_bg_card()),
            ("quote_params", "一言请求参数", "主页/桌面一言的分类与长度",
             FluentIcon.EDIT, self._build_quote_params_card()),
            ("advanced", "高级功能", "浮窗文字的动态颜色效果",
             FluentIcon.EMOJI_TAB_SYMBOLS, self._build_advanced_card()),
            ("theme", "主题", "主题色与明暗模式",
             FluentIcon.PALETTE, self._build_theme_card()),
            ("exam", "考试管理", "考试项目与倒计时日期",
             FluentIcon.DOCUMENT, self._build_exam_card()),
            ("selfcheck", "功能自检", "检查各项功能是否正常",
             FluentIcon.HEART, self._build_selfcheck_card()),
        ]

        list_page = QWidget()
        lv = QVBoxLayout(list_page)
        lv.setContentsMargins(28, 20, 28, 20)
        lv.setSpacing(12)
        for key, title, desc, icon, _ in cards:
            item = _NavSettingCard(icon, title, desc)
            arrow = ToolButton(FluentIcon.CHEVRON_RIGHT)
            arrow.setAttribute(Qt.WA_TransparentForMouseEvents)
            item.hBoxLayout.addWidget(arrow)
            item.clicked.connect(lambda k=key: self._open_settings_sub(k))
            lv.addWidget(item)
        lv.addStretch()
        self._settings_stack.addWidget(list_page)

        for key, title, desc, icon, content in cards:
            self._settings_stack.addWidget(self._wrap_subpage(title, content))

        lay = QVBoxLayout(self.settings_page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._settings_stack)

    def _wrap_subpage(self, title, content) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(28, 14, 28, 20)
        v.setSpacing(12)
        back = PushButton("返回")
        back.clicked.connect(lambda: self._settings_stack.setCurrentIndex(0))
        v.addWidget(back, 0, Qt.AlignLeft)
        v.addWidget(content)
        v.addStretch()
        return page

    def _open_settings_sub(self, key):
        keys = ["general", "widget_bg", "quote_params", "advanced",
                "theme", "exam", "selfcheck"]
        self._settings_stack.setCurrentIndex(keys.index(key) + 1)

    def _build_general_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(12)
        v.addWidget(StrongBodyLabel("通用设置"))

        self.autostart_cb = CheckBox("开机自动启动，静默换壁纸")
        self.autostart_cb.setChecked(core.is_autostart_enabled())
        self.autostart_cb.toggled.connect(self._on_autostart_toggled)
        v.addWidget(self.autostart_cb)

        self.float_cb = CheckBox("显示浮动倒计时窗口")
        self.float_cb.setChecked(core.load_config().get("floating_widget", True))
        self.float_cb.toggled.connect(self._toggle_floating)
        v.addWidget(self.float_cb)

        self.wm_cb = CheckBox("显示桌面水印 power by TFC")
        self.wm_cb.setChecked(core.load_config().get("show_watermark", True))
        self.wm_cb.toggled.connect(self._toggle_watermark)
        v.addWidget(self.wm_cb)

        self.quote_cb = CheckBox("桌面显示一言")
        self.quote_cb.setChecked(core.load_config().get("show_quote_widget", True))
        self.quote_cb.toggled.connect(self._toggle_quote)
        v.addWidget(self.quote_cb)
        return card

    def _build_widget_bg_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(12)
        v.addWidget(StrongBodyLabel("桌面组件背景"))

        cfg = core.load_config()
        for key, title in (("float_bg", "倒计时浮窗背景"), ("wm_bg", "水印背景"),
                           ("quote_widget_bg", "一言打字机背景")):
            row = QHBoxLayout()
            row.setSpacing(10)
            lab = CaptionLabel(title)
            lab.setFixedWidth(108)
            row.addWidget(lab)
            cur = QColor(cfg.get(key, "#0C1120"))
            cur.setAlpha(cfg.get(key + "_alpha", 255))
            picker = ColorPickerButton(cur, title, card, enableAlpha=True)
            if key == "quote_widget_bg":
                picker.colorChanged.connect(self._apply_quote_bg)
            else:
                picker.colorChanged.connect(lambda c, k=key: self._apply_widget_bg(k, c))
            row.addWidget(picker)
            row.addStretch()
            v.addLayout(row)

        nfg = QHBoxLayout()
        nfg.setSpacing(10)
        nfg_lab = CaptionLabel("倒计时数字颜色")
        nfg_lab.setFixedWidth(108)
        nfg.addWidget(nfg_lab)
        self.float_fg = ColorPickerButton(QColor(cfg.get("float_fg", "#FF7A6C")),
                                          "数字颜色", card)
        self.float_fg.colorChanged.connect(self._apply_float_fg)
        nfg.addWidget(self.float_fg)
        nfg.addStretch()
        v.addLayout(nfg)

        fs = QHBoxLayout()
        fs.setSpacing(10)
        fs_lab = CaptionLabel("一言打字机字号")
        fs_lab.setFixedWidth(108)
        fs.addWidget(fs_lab)
        self.quote_fs = SpinBox()
        self.quote_fs.setRange(10, 48)
        self.quote_fs.setValue(int(cfg.get("quote_widget_fs", 16) or 16))
        self.quote_fs.valueChanged.connect(self._apply_quote_fs)
        fs.addWidget(self.quote_fs)
        fs.addStretch()
        v.addLayout(fs)

        fg = QHBoxLayout()
        fg.setSpacing(10)
        fg_lab = CaptionLabel("一言打字机字体颜色")
        fg_lab.setFixedWidth(108)
        fg.addWidget(fg_lab)
        self.quote_fg = ColorPickerButton(QColor(cfg.get("quote_widget_fg", "#FFFFFF")),
                                          "字体颜色", card)
        self.quote_fg.colorChanged.connect(self._apply_quote_fg)
        fg.addWidget(self.quote_fg)
        fg.addStretch()
        v.addLayout(fg)

        upd = QHBoxLayout()
        upd.setSpacing(10)
        upd_lab = CaptionLabel("一言打字机")
        upd_lab.setFixedWidth(108)
        upd.addWidget(upd_lab)
        upd_btn = PushButton("立即更新")
        upd_btn.clicked.connect(self._refresh_quote_now)
        upd.addWidget(upd_btn)
        upd.addStretch()
        v.addLayout(upd)
        return card

    def _build_quote_params_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(14)
        v.addWidget(StrongBodyLabel("一言请求参数"))
        v.addWidget(CaptionLabel("配置主页/桌面一言的文章分类与长度"))

        cfg = core.load_config()

        def add_group(key_prefix, title, defaults):
            v.addWidget(StrongBodyLabel(title))
            cbs = {}
            row = QHBoxLayout()
            row.setSpacing(8)
            for code, name in HITOKOTO_CAT_NAMES.items():
                cb = CheckBox(name)
                cb.setChecked(code in cfg.get(key_prefix + "_cats", defaults))
                cbs[code] = cb
                row.addWidget(cb)
            row.addStretch()
            v.addLayout(row)

            lim = QHBoxLayout()
            lim.setSpacing(8)
            minb = SpinBox()
            minb.setRange(0, 100)
            minb.setValue(int(cfg.get(key_prefix + "_min", 0)))
            maxb = SpinBox()
            maxb.setRange(1, 200)
            maxb.setValue(int(cfg.get(key_prefix + "_max", 40)))
            lim.addWidget(CaptionLabel("最短"))
            lim.addWidget(minb)
            lim.addWidget(CaptionLabel("最长"))
            lim.addWidget(maxb)
            lim.addStretch()
            v.addLayout(lim)

            def save():
                c = core.load_config()
                c[key_prefix + "_cats"] = [k for k in cbs if cbs[k].isChecked()]
                c[key_prefix + "_min"] = minb.value()
                c[key_prefix + "_max"] = maxb.value()
                core.save_config(c)
                self._hitokoto_params_changed()
                InfoBar.success("已保存", title + " 参数已应用", parent=self, duration=1800,
                                position=InfoBarPosition.TOP_RIGHT)

            btn = PushButton("应用")
            btn.clicked.connect(save)
            v.addWidget(btn, 0, Qt.AlignRight)

        add_group("home", "主页一言", ("d", "e", "f", "j", "k"))
        add_group("tw", "桌面一言", ("d", "e", "f", "j", "k"))
        return card

    def _hitokoto_params_changed(self):
        rebuild_hitokoto_params()

    def _build_advanced_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(12)
        v.addWidget(StrongBodyLabel("高级功能"))
        v.addWidget(CaptionLabel("为各个浮窗的文字单独设置动态颜色效果"))

        cfg = core.load_config()
        for key, title in (("float_fx", "倒计时数字"), ("wm_fx", "水印文字"),
                           ("quote_fx", "桌面一言")):
            row = QHBoxLayout()
            row.setSpacing(10)
            lab = CaptionLabel(title)
            lab.setFixedWidth(108)
            row.addWidget(lab)
            cb = ComboBox()
            cb.addItems(FX_LABELS)
            cur = cfg.get(key, "none")
            cb.setCurrentIndex(FX_NAMES.index(cur) if cur in FX_NAMES else 0)
            cb.currentIndexChanged.connect(lambda idx, k=key: self._apply_fx(k, idx))
            row.addWidget(cb)
            row.addStretch()
            v.addLayout(row)
        return card

    def _apply_fx(self, key, idx):
        name = FX_NAMES[idx]
        cfg = core.load_config()
        cfg[key] = name
        core.save_config(cfg)
        if key == "float_fx":
            self.float_widget.set_fx(name)
        elif key == "wm_fx":
            self.wm_widget.set_fx(name)
        else:
            self.quote_widget.set_fx(name)

    def _apply_float_fg(self, color):
        cfg = core.load_config()
        cfg["float_fg"] = color.name()
        core.save_config(cfg)
        self.float_widget.set_fg(color.name())

    def _apply_widget_bg(self, key, color):
        cfg = core.load_config()
        cfg[key] = color.name()
        cfg[key + "_alpha"] = color.alpha()
        core.save_config(cfg)
        if key == "float_bg":
            self.float_widget.set_bg(color.name(), color.alpha())
        else:
            self.wm_widget.set_bg(color.name(), color.alpha())

    def _build_theme_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(12)
        v.addWidget(StrongBodyLabel("主题颜色"))
        row = QHBoxLayout()
        row.setSpacing(12)
        cur = core.load_config().get("theme_color", "#0078D4")
        self.theme_picker = ColorPickerButton(QColor(cur), "主题颜色", card)
        self.theme_picker.colorChanged.connect(self._apply_theme_color)
        row.addWidget(self.theme_picker)
        row.addStretch()
        v.addLayout(row)
        return card

    def _build_exam_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(12)
        v.addWidget(StrongBodyLabel("考试管理"))

        row3 = QHBoxLayout()
        row3.setSpacing(10)
        lab3 = CaptionLabel("当前考试")
        lab3.setFixedWidth(72)
        row3.addWidget(lab3)
        self.active_combo = ComboBox()
        self.active_combo.currentIndexChanged.connect(self._on_active_changed)
        row3.addWidget(self.active_combo, 1)
        v.addLayout(row3)

        self.exam_list = ListWidget()
        self.exam_list.setFixedHeight(96)
        v.addWidget(self.exam_list)

        exb = QHBoxLayout()
        exb.setSpacing(10)
        b_add = PushButton("添加")
        b_edit = PushButton("编辑")
        b_del = PushButton("删除")
        b_add.clicked.connect(self._add_exam)
        b_edit.clicked.connect(self._edit_exam)
        b_del.clicked.connect(self._del_exam)
        for b in (b_add, b_edit, b_del):
            exb.addWidget(b)
        exb.addStretch()
        v.addLayout(exb)
        return card

    def _build_selfcheck_card(self) -> QWidget:
        card = CardWidget()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 20, 22, 20)
        v.setSpacing(10)
        head = QHBoxLayout()
        head.addWidget(StrongBodyLabel("功能自检"))
        head.addStretch()
        recheck = PushButton("重新自检")
        recheck.clicked.connect(self.run_self_check)
        head.addWidget(recheck)
        v.addLayout(head)
        self.check_holder = QVBoxLayout()
        self.check_holder.setSpacing(8)
        v.addLayout(self.check_holder)
        return card

    def _build_tray(self):
        self.tray = QSystemTrayIcon(self)
        icon_path = res_path("icon.png")
        if icon_path.exists():
            self.tray.setIcon(QIcon(str(icon_path)))
        self.tray.setToolTip("有心Desktop")
        menu = QMenu()
        # setContextMenu 不接管菜单所有权, 必须自己持有引用, 否则会被 GC、右键无菜单
        self.tray_menu = menu
        a_show = QAction("显示主界面", menu)
        a_show.triggered.connect(self.show_and_raise)
        a_swap = QAction("立即换今天的壁纸", menu)
        a_swap.triggered.connect(lambda: self.apply_settings(silent=True))
        a_open = QAction("打开壁纸文件夹", menu)
        a_open.triggered.connect(lambda: os.startfile(str(core.wallpaper_dir())))
        self.act_float = QAction("浮动倒计时窗口", menu, checkable=True)
        self.act_float.setChecked(core.load_config().get("floating_widget", True))
        self.act_float.toggled.connect(self._on_tray_float)
        self.act_autostart = QAction("开机自启", menu, checkable=True)
        self.act_autostart.setChecked(core.is_autostart_enabled())
        self.act_autostart.toggled.connect(self._on_tray_autostart)
        a_exit = QAction("退出", menu)
        a_exit.triggered.connect(self.real_exit)
        menu.addAction(a_show)
        menu.addSeparator()
        menu.addAction(a_swap)
        menu.addAction(a_open)
        menu.addAction(self.act_float)
        menu.addAction(self.act_autostart)
        menu.addSeparator()
        menu.addAction(a_exit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._on_tray_activated)
        self.tray.show()

    def _on_tray_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self.show_and_raise()

    def _on_tray_autostart(self, checked):
        core.set_autostart(checked)
        self.autostart_cb.blockSignals(True)
        self.autostart_cb.setChecked(core.is_autostart_enabled())
        self.autostart_cb.blockSignals(False)

    def _on_tray_float(self, checked):
        self.float_cb.blockSignals(True)
        self.float_cb.setChecked(checked)
        self.float_cb.blockSignals(False)
        self._toggle_floating(checked)

    def _on_autostart_toggled(self, checked):
        core.set_autostart(checked)

    def choose_folder(self):
        d = QFileDialog.getExistingDirectory(self, "选择壁纸文件夹",
                                             self.folder_edit.text() or str(BASE_DIR))
        if d:
            self.folder_edit.setText(d)

    def _apply_theme_color(self, color):
        setThemeColor(color)
        cfg = core.load_config()
        cfg["theme_color"] = color.name()
        core.save_config(cfg)
        self.flash_status("主题颜色已切换")

    def _toggle_floating(self, on):
        cfg = core.load_config()
        cfg["floating_widget"] = bool(on)
        core.save_config(cfg)
        if on:
            self.float_widget.show()
            QTimer.singleShot(300, lambda: send_to_bottom(self.float_widget))
        else:
            self.float_widget.hide()

    def _toggle_watermark(self, on):
        cfg = core.load_config()
        cfg["show_watermark"] = bool(on)
        core.save_config(cfg)
        if on:
            self.wm_widget.show()
            QTimer.singleShot(300, lambda: send_to_bottom(self.wm_widget))
        else:
            self.wm_widget.hide()

    def _toggle_quote(self, on):
        cfg = core.load_config()
        cfg["show_quote_widget"] = bool(on)
        core.save_config(cfg)
        if on:
            self.quote_widget.show()
            QTimer.singleShot(300, lambda: send_to_bottom(self.quote_widget))
        else:
            self.quote_widget.hide()

    def _apply_quote_bg(self, color):
        cfg = core.load_config()
        cfg["quote_widget_bg"] = color.name()
        cfg["quote_widget_bg_alpha"] = color.alpha()
        core.save_config(cfg)
        self.quote_widget.set_bg(color.name(), color.alpha())

    def _apply_quote_fs(self, value):
        cfg = core.load_config()
        cfg["quote_widget_fs"] = int(value)
        core.save_config(cfg)
        self.quote_widget.apply_font(int(value))

    def _apply_quote_fg(self, color):
        cfg = core.load_config()
        cfg["quote_widget_fg"] = color.name()
        core.save_config(cfg)
        self.quote_widget.set_fg(color.name())

    def _refresh_quote_now(self):
        self.quote_widget.refresh_now()
        InfoBar.success("已更新", "正在获取新的一言", parent=self, duration=1500,
                        position=InfoBarPosition.TOP_RIGHT)

    def apply_settings(self, silent=False):
        cfg = core.load_config()
        folder = self.folder_edit.text().strip() or str(BASE_DIR / "壁纸")
        cfg["wallpaper_dir"] = folder
        cfg["fit_mode"] = "center" if self.fit_combo.currentIndex() == 1 else "stretch"
        core.save_config(cfg)
        Path(folder).mkdir(parents=True, exist_ok=True)
        res = core.apply_today(force=True)
        self.refresh_all()
        if not silent:
            self.flash_status(res["msg"], res["ok"])
        return res

    def refresh_all(self):
        cfg = core.load_config()
        if self.folder_edit.text() != cfg["wallpaper_dir"]:
            self.folder_edit.setText(cfg["wallpaper_dir"])
        self.fit_combo.setCurrentIndex(0 if cfg.get("fit_mode", "stretch") == "stretch" else 1)
        self.refresh_gallery()
        self.refresh_exam_list()
        self.run_self_check()

    def refresh_from_state(self, _state):
        self.refresh_all()

    def refresh_gallery(self):
        folder = core.wallpaper_dir()
        folder.mkdir(parents=True, exist_ok=True)
        items = core.list_images(folder)
        fit = core.load_config().get("fit_mode", "stretch")
        sig = ([p for _, p in items], fit)
        # 文件列表没变就复用已有卡片, 避免每次 refresh_all 都重建 300 个控件
        if sig == getattr(self, "_gal_sig", None):
            self._gal_timer.start()
            return
        self._gal_sig = sig
        while self.gallery_grid.count():
            item = self.gallery_grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        cols = 3
        self._gal_cards = []
        for i, (d, path) in enumerate(items):
            c = DayCard(d, path, fit)
            self.gallery_grid.addWidget(c, i // cols, i % cols)
            self._gal_cards.append(c)
        if not items:
            tip = CaptionLabel("壁纸文件夹是空的\n把图片放进来，文件名带倒计时天数")
            tip.setAlignment(Qt.AlignCenter)
            self.gallery_grid.addWidget(tip, 0, 0, 1, cols)
        self.gallery_count.setText("%d 张图片" % len(items) if items else "空")
        self._gal_timer.start()

    def flash_status(self, text, ok=True):
        if ok:
            InfoBar.success("", text, parent=self, duration=2600, position=InfoBarPosition.TOP)
        else:
            InfoBar.error("", text, parent=self, duration=2600, position=InfoBarPosition.TOP)

    def run_self_check(self):
        while self.check_holder.count():
            it = self.check_holder.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()

        cfg = core.load_config()
        day = core.countdown()
        folder = core.wallpaper_dir()
        exams = core.get_exams(cfg)
        today_img = core.find_wallpaper(folder, day)

        items = [
            ("倒计时计算", day >= 0, "距高考 %s 天" % day),
            ("壁纸文件夹", folder.is_dir(), str(folder)),
            ("今日壁纸匹配", today_img is not None,
             "%s" % today_img.name if today_img else "缺少文件名带 %s 的图片" % day),
            ("文件名数字识别", len(core.list_images(folder)) > 0,
             "识别到 %s 张图片" % len(core.list_images(folder))),
            ("换壁纸接口", hasattr(ctypes.windll.user32, "SystemParametersInfoW"), "Windows API 可用"),
            ("开机自启", core.is_autostart_enabled(),
             "已配置" if core.is_autostart_enabled() else "未开启"),
            ("浮动倒计时窗", cfg.get("floating_widget", True),
             "已显示在桌面壁纸层" if cfg.get("floating_widget", True) else "已关闭"),
            ("桌面水印", cfg.get("show_watermark", True),
             "power by TFC 已显示" if cfg.get("show_watermark", True) else "已关闭"),
            ("浮窗层级", True, "已固定在其他窗口之下"),
            ("桌面一言打字机", cfg.get("show_quote_widget", True),
             "已显示" if cfg.get("show_quote_widget", True) else "已关闭"),
            ("考试配置", len(exams) > 0 and core.exam_target_date().year >= 2026,
             "%d 个考试，目标 %s" % (len(exams), core.exam_target_date())),
        ]
        for name, ok, detail in items:
            row = QHBoxLayout()
            row.setSpacing(10)
            icon = QLabel("✓" if ok else "✗")
            icon.setFixedSize(22, 22)
            icon.setAlignment(Qt.AlignCenter)
            icon.setStyleSheet("background:%s; color:white; border-radius:11px; font-weight:900;"
                               % ("#2ECC71" if ok else "#E74C3C"))
            row.addWidget(icon)
            nm = BodyLabel(name)
            nm.setFixedWidth(110)
            row.addWidget(nm)
            dt = CaptionLabel(detail)
            dt.setStyleSheet("color:#7A8296;")
            row.addWidget(dt, 1)
            wrap = QWidget()
            wrap.setLayout(row)
            self.check_holder.addWidget(wrap)

    def refresh_exam_list(self):
        cfg = core.load_config()
        exams = core.get_exams(cfg)
        self.active_combo.blockSignals(True)
        self.active_combo.clear()
        self.active_combo.addItem("自动(最近未到期)", userData=-1)
        for i, e in enumerate(exams):
            self.active_combo.addItem("%s (%s)" % (e.get("name", "考试"), e.get("date", "06-07")),
                                      userData=i)
        idx = cfg.get("active_exam", -1)
        pos = self.active_combo.findData(idx)
        self.active_combo.setCurrentIndex(pos if pos >= 0 else 0)
        self.active_combo.blockSignals(False)

        self.exam_list.clear()
        for e in exams:
            self.exam_list.addItem("%s   ·   %s" % (e.get("name", "考试"),
                                                    e.get("date", "06-07")))

    def _on_active_changed(self, _):
        cfg = core.load_config()
        data = self.active_combo.currentData()
        cfg["active_exam"] = data if isinstance(data, int) else -1
        core.save_config(cfg)
        self.refresh_all()

    def _exam_dialog(self, exam=None):
        exam = exam or {"name": "新考试", "date": "06-07"}
        from PySide6.QtWidgets import QDialog, QDialogButtonBox
        d = QDialog(self)
        d.setWindowTitle("编辑考试")
        d.setFixedWidth(340)
        v = QVBoxLayout(d)
        v.setSpacing(10)
        v.addWidget(BodyLabel("考试名称"))
        name = LineEdit()
        name.setText(exam.get("name", ""))
        v.addWidget(name)
        v.addWidget(BodyLabel("日期 (MM-DD 或 YYYY-MM-DD)"))
        date_le = LineEdit()
        date_le.setText(exam.get("date", "06-07"))
        v.addWidget(date_le)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(d.accept)
        bb.rejected.connect(d.reject)
        v.addWidget(bb)
        if d.exec() != QDialog.Accepted:
            return None
        return {"name": name.text().strip() or "考试",
                "date": date_le.text().strip() or "06-07"}

    def _add_exam(self):
        ex = self._exam_dialog()
        if ex:
            cfg = core.load_config()
            cfg.setdefault("exams", []).append(ex)
            core.save_config(cfg)
            self.refresh_all()
            self.flash_status("已添加考试: " + ex["name"])

    def _selected_exam_row(self) -> int:
        """返回当前选中行; 未选但列表非空时默认取第一行, 便于直接编辑/删除。"""
        row = self.exam_list.currentRow()
        if row < 0 and self.exam_list.count():
            row = 0
            self.exam_list.setCurrentRow(0)
        return row

    def _edit_exam(self):
        row = self._selected_exam_row()
        if row < 0:
            self.flash_status("请先添加一个考试", ok=False)
            return
        cfg = core.load_config()
        exams = core.get_exams(cfg)
        if row >= len(exams):
            return
        ex = self._exam_dialog(exams[row])
        if ex:
            exams[row] = ex
            cfg["exams"] = exams
            core.save_config(cfg)
            self.refresh_all()
            self.flash_status("已更新考试: " + ex["name"])

    def _del_exam(self):
        row = self._selected_exam_row()
        if row < 0:
            self.flash_status("请先添加一个考试", ok=False)
            return
        cfg = core.load_config()
        exams = core.get_exams(cfg)
        if row >= len(exams):
            return
        name = exams[row].get("name", "考试")
        if QMessageBox.question(self, "删除考试", "确定删除「%s」吗?" % name) != QMessageBox.Yes:
            return
        exams.pop(row)
        cfg["exams"] = exams if exams else list(core.DEFAULT_EXAMS)
        if cfg.get("active_exam", -1) >= len(cfg["exams"]):
            cfg["active_exam"] = -1
        core.save_config(cfg)
        self.refresh_all()
        self.flash_status("已删除考试: " + name)

    def post_state(self, state):
        self.stateChanged.emit(state)

    @Slot()
    def show_and_raise(self):
        try:
            self.showNormal()
            # 静默启动时窗口未创建, 固定尺寸不会被应用, 这里重新校正一次
            self.resize(1000, 680)
            self.show()
            self.raise_()
            self.activateWindow()
            hwnd = int(self.winId())
            ctypes.windll.user32.ShowWindow(hwnd, 9)
            ctypes.windll.user32.ShowWindow(hwnd, 5)
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception as e:
            core.logger.warning("显示窗口失败: %s", e)
        if hasattr(self, "home"):
            self.home.resume_feed()

    def closeEvent(self, ev):
        ev.ignore()
        self.hide()
        self.home.pause_feed()

    def changeEvent(self, ev):
        super().changeEvent(ev)
        if ev.type() == QEvent.Type.WindowStateChange and hasattr(self, "home"):
            if self.isMinimized() or not self.isVisible():
                self.home.pause_feed()
            else:
                self.home.resume_feed()

    def real_exit(self):
        self.tray.hide()
        QApplication.quit()
        os._exit(0)


def main():
    args = sys.argv[1:]
    if "--once" in args:
        core.apply_today(force=True)
        return
    if core.notify_running_instance():
        return

    app = QApplication(sys.argv)
    app.setApplicationName("有心Desktop")
    app.setQuitOnLastWindowClosed(False)

    # --windowed 打包后 stderr 为 None, 未捕获异常会被静默吞掉, 统一记到日志文件
    def _log_exc(exc_type, exc, tb):
        core.logger.error("未捕获异常", exc_info=(exc_type, exc, tb))

    sys.excepthook = _log_exc
    threading.excepthook = lambda a: core.logger.error(
        "线程未捕获异常", exc_info=(a.exc_type, a.exc_value, a.exc_traceback))

    setTheme(Theme.LIGHT)
    setThemeColor(QColor(core.load_config().get("theme_color", "#0078D4")))

    icon_path = res_path("icon.png")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    minimized = "--minimized" in args
    win_holder = {}

    def build_main():
        win = MainWindow(start_minimized=minimized)
        win_holder["win"] = win

        def ipc_show():
            win.showRequested.emit()

        core.start_ipc_server(ipc_show)
        threading.Thread(target=core.run_daily_loop, args=(win.post_state,), daemon=True).start()

    loading = LoadingScreen()
    loading.hide()   # 无启动动画版: 不显示开场窗口, 300ms 后直接进主界面

    def on_loading_done():
        loading.close()
        build_main()

    loading.finished.connect(on_loading_done)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
